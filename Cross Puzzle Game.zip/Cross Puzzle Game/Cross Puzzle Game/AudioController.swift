//
//  AudioController.swift
//  Cross Puzzle Game
//
//  Created by CampusUser on 4/17/19.
//  Copyright © 2019 Big Nerd Ranch. All rights reserved.
//

import AVFoundation

class AudioController {
    private var audio = [String:AVAudioPlayer]()
    
    func preloadAudioEffects(effectFileNames:[String]) {
        for effect in AudioEffectFiles {
            //1 get the file path URL
            let soundURL = Bundle.main.resourceURL!.appendingPathComponent(effect)
            
            //2 load the file contents
            do {
                let player = try AVAudioPlayer(contentsOf: soundURL)
                //3 prepare the play
                player.numberOfLoops = 0
                player.prepareToPlay()
                
                //4 add to the audio dictionary
                audio[effect] = player
                
            } catch { print(error) }
        }
    }
    
    func playEffect(name:String) {
        if let player = audio[name] {
            if player.isPlaying {
                player.currentTime = 0
            } else {
                player.play()
            }
        }
    }
    
    
}
