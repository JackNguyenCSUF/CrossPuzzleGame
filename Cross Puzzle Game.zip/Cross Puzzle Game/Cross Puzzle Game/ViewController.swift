//
//  ViewController.swift
//  Cross Puzzle Game
//
//  Created by CampusUser on 4/17/19.
//  Copyright © 2019 Big Nerd Ranch. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController {
    let button1 = UIButton()
    let button2 = UIButton()
    let button3 = UIButton()
    let button4 = UIButton()
    let button5 = UIButton()
    let button6 = UIButton()
    let button7 = UIButton()
    let button8 = UIButton()
    let button9 = UIButton()
    let button10 = UIButton()
    let button11 = UIButton()
    let button12 = UIButton()
    let button13 = UIButton()
    let button14 = UIButton()
    let button15 = UIButton()
    let button16 = UIButton()
    let button17 = UIButton()
    let button18 = UIButton()
    let button19 = UIButton()
    let button20 = UIButton()
    let button21 = UIButton()
    let button22 = UIButton()
    let button23 = UIButton()
    let button24 = UIButton()
    let button25 = UIButton()
    let button26 = UIButton()
    let button27 = UIButton()
    let button28 = UIButton()
    let button29 = UIButton()
    let button30 = UIButton()
    let button31 = UIButton()
    let button32 = UIButton()
    let button33 = UIButton()
    let button34 = UIButton()
    let button35 = UIButton()
    let button36 = UIButton()
    let button37 = UIButton()
    let button38 = UIButton()
    let button39 = UIButton()
    let button40 = UIButton()
    let button41 = UIButton()
    let button42 = UIButton()
    let button43 = UIButton()
    let button44 = UIButton()
    let button45 = UIButton()
    let button46 = UIButton()
    
    //let hintButtonImage = UIImage(named: "btn")!
    private var data = GameData()
    var finishButton: UIButton!
    
    lazy var buttons1: [UIButton] = [self.button1, self.button2, self.button3, self.button4, self.button5, self.button26, self.button27]
    lazy var buttons2: [UIButton] = [self.button28, self.button29, self.button30]
    lazy var buttons3: [UIButton] = [self.button8, self.button15, self.button27, self.button32, self.button37, self.button43]
    lazy var buttons4: [UIButton] = [self.button11, self.button12, self.button13, self.button14]
    lazy var buttons5: [UIButton] = [self.button5, self.button9, self.button18, self.button34, self.button38, self.button39, self.button44]
    lazy var buttons6: [UIButton] = [self.button23, self.button24, self.button25]
    lazy var buttons7: [UIButton] = [self.button31, self.button32, self.button33,self.button34, self.button35]
    lazy var buttons8: [UIButton] = [self.button19, self.button20, self.button21,self.button22, self.button45,self.button46]
     lazy var buttons9: [UIButton] = [self.button1, self.button6, self.button10, self.button11, self.button16,self.button29, self.button40]
     lazy var buttons10: [UIButton] = [self.button3, self.button7, self.button14,self.button31, self.button36, self.button42]
     lazy var buttons11: [UIButton] = [self.button13, self.button17, self.button19,self.button24, self.button41]
    lazy var buttons12: [UIButton] = [self.button1, self.button2, self.button3, self.button4, self.button5, self.button6, self.button7, self.button8, self.button9, self.button10, self.button11, self.button12, self.button13, self.button14, self.button15, self.button16, self.button17, self.button18, self.button46, self.button19, self.button20, self.button21, self.button22, self.button23, self.button24, self.button25, self.button26, self.button27, self.button28, self.button29, self.button30, self.button31, self.button32, self.button33, self.button34, self.button35, self.button36, self.button37, self.button38, self.button39, self.button40, self.button41, self.button42, self.button43, self.button44, self.button45 ]
    
    var buttonsDisable = [UIButton]()
    
    private let controller: GameController
    
    required init(coder aDecoder: NSCoder) {
        controller = GameController()
        super.init(coder: aDecoder)!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let gameView = UIView(frame: CGRect(x: 0,y: 0, width: ScreenWidth,height: ScreenHeight))
        self.view.addSubview(gameView)
        controller.gameView = gameView
        
        //add one view for all hud and controls
        let hudView = HUDView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height: ScreenHeight))
        self.view.addSubview(hudView)
        controller.hud = hudView
        controller.onAnagramSolved = self.showWord
        
        button1.backgroundColor = UIColor.white
        button1.setTitle("P", for: .normal)
        button1.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.view.addSubview(button1)
        button1.translatesAutoresizingMaskIntoConstraints = false
        let views1 = ["button": button1]
        let constraintHorizontal1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-50-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views1)
        view.addConstraints(constraintHorizontal1)
        let constraintWertical1 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-100-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views1)
        view.addConstraints(constraintWertical1)
        
        button2.backgroundColor = UIColor.white
        button2.setTitle("A", for: .normal)
        button2.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.view.addSubview(button2)
        button2.translatesAutoresizingMaskIntoConstraints = false
        let views2 = ["button": button2]
        let constraintHorizontal2 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-90-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views2)
        view.addConstraints(constraintHorizontal2)
        let constraintWertical2 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-100-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views2)
        view.addConstraints(constraintWertical2)
        
        button26.backgroundColor = UIColor.white
        button26.setTitle("S", for: .normal)
        button26.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.view.addSubview(button26)
        button26.translatesAutoresizingMaskIntoConstraints = false
        let views26 = ["button": button26]
        let constraintHorizontal26 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-130-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views26)
        view.addConstraints(constraintHorizontal26)
        let constraintWertical26 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-100-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views26)
        view.addConstraints(constraintWertical26)
        
        button27.backgroundColor = UIColor.white
        button27.setTitle("I", for: .normal)
        button27.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.view.addSubview(button27)
        button27.translatesAutoresizingMaskIntoConstraints = false
        let views27 = ["button": button27]
        let constraintHorizontal27 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-210-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views27)
        view.addConstraints(constraintHorizontal27)
        let constraintWertical27 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-100-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views27)
        view.addConstraints(constraintWertical27)
        
        button3.backgroundColor = UIColor.white
        button3.setTitle("S", for: .normal)
        button3.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.view.addSubview(button3)
        button3.translatesAutoresizingMaskIntoConstraints = false
        let views3 = ["button": button3]
        let constraintHorizontal3 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-170-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views3)
        view.addConstraints(constraintHorizontal3)
        let constraintWertical3 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-100-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views3)
        view.addConstraints(constraintWertical3)
        
        button4.backgroundColor = UIColor.white
        button4.setTitle("O", for: .normal)
        button4.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.view.addSubview(button4)
        button4.translatesAutoresizingMaskIntoConstraints = false
        let views4 = ["button": button4]
        let constraintHorizontal4 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-250-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views4)
        view.addConstraints(constraintHorizontal4)
        let constraintWertical4 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-100-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views4)
        view.addConstraints(constraintWertical4)
        
        button5.backgroundColor = UIColor.white
        button5.setTitle("N", for: .normal)
        button5.addTarget(self, action: #selector(buttonAction), for: .touchUpInside)
        self.view.addSubview(button5)
        button5.translatesAutoresizingMaskIntoConstraints = false
        let views5 = ["button": button5]
        let constraintHorizontal5 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-290-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views5)
        view.addConstraints(constraintHorizontal5)
        let constraintWertical5 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-100-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views5)
        view.addConstraints(constraintWertical5)
        
        button6.backgroundColor = UIColor.white
        button6.setTitle("P", for: .normal)
        button6.addTarget(self, action: #selector(buttonAction9), for: .touchUpInside)
        self.view.addSubview(button6)
        button6.translatesAutoresizingMaskIntoConstraints = false
        let views6 = ["button": button6]
        let constraintHorizontal6 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-50-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views6)
        view.addConstraints(constraintHorizontal6)
        let constraintWertical6 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-180-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views6)
        view.addConstraints(constraintWertical6)
        
        button7.backgroundColor = UIColor.white
        button7.setTitle("L", for: .normal)
        button7.addTarget(self, action: #selector(buttonAction10), for: .touchUpInside)
        self.view.addSubview(button7)
        button7.translatesAutoresizingMaskIntoConstraints = false
        let views7 = ["button": button7]
        let constraintHorizontal7 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-170-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views7)
        view.addConstraints(constraintHorizontal7)
        let constraintWertical7 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-180-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views7)
        view.addConstraints(constraintWertical7)
        
        button8.backgroundColor = UIColor.white
        button8.setTitle("C", for: .normal)
        button8.addTarget(self, action: #selector(buttonAction2), for: .touchUpInside)
        self.view.addSubview(button8)
        button8.translatesAutoresizingMaskIntoConstraints = false
        let views8 = ["button": button8]
        let constraintHorizontal8 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-210-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views8)
        view.addConstraints(constraintHorizontal8)
        let constraintWertical8 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-180-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views8)
        view.addConstraints(constraintWertical8)
        
        button9.backgroundColor = UIColor.white
        button9.setTitle("U", for: .normal)
        button9.addTarget(self, action: #selector(buttonAction4), for: .touchUpInside)
        self.view.addSubview(button9)
        button9.translatesAutoresizingMaskIntoConstraints = false
        let views9 = ["button": button9]
        let constraintHorizontal9 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-290-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views9)
        view.addConstraints(constraintHorizontal9)
        let constraintWertical9 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-180-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views9)
        view.addConstraints(constraintWertical9)
        
        button10.backgroundColor = UIColor.white
        button10.setTitle("U", for: .normal)
        button10.addTarget(self, action: #selector(buttonAction9), for: .touchUpInside)
        self.view.addSubview(button10)
        button10.translatesAutoresizingMaskIntoConstraints = false
        let views10 = ["button": button10]
        let constraintHorizontal10 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-50-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views10)
        view.addConstraints(constraintHorizontal10)
        let constraintWertical10 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-220-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views10)
        view.addConstraints(constraintWertical10)
        
        button11.backgroundColor = UIColor.white
        button11.setTitle("L", for: .normal)
        button11.addTarget(self, action: #selector(buttonAction9), for: .touchUpInside)
        self.view.addSubview(button11)
        button11.translatesAutoresizingMaskIntoConstraints = false
        let views11 = ["button": button11]
        let constraintHorizontal11 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-50-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views11)
        view.addConstraints(constraintHorizontal11)
        let constraintWertical11 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-260-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views11)
        view.addConstraints(constraintWertical11)
        
        button12.backgroundColor = UIColor.white
        button12.setTitle("I", for: .normal)
        button12.addTarget(self, action: #selector(buttonAction3), for: .touchUpInside)
        self.view.addSubview(button12)
        button12.translatesAutoresizingMaskIntoConstraints = false
        let views12 = ["button": button12]
        let constraintHorizontal12 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-90-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views12)
        view.addConstraints(constraintHorizontal12)
        let constraintWertical12 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-260-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views12)
        view.addConstraints(constraintWertical12)
        
        button13.backgroundColor = UIColor.white
        button13.setTitle("O", for: .normal)
        button13.addTarget(self, action: #selector(buttonAction3), for: .touchUpInside)
        self.view.addSubview(button13)
        button13.translatesAutoresizingMaskIntoConstraints = false
        let views13 = ["button": button13]
        let constraintHorizontal13 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-130-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views13)
        view.addConstraints(constraintHorizontal13)
        let constraintWertical13 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-260-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views13)
        view.addConstraints(constraintWertical13)
        
        button14.backgroundColor = UIColor.white
        button14.setTitle("N", for: .normal)
        button14.addTarget(self, action: #selector(buttonAction10), for: .touchUpInside)
        self.view.addSubview(button14)
        button14.translatesAutoresizingMaskIntoConstraints = false
        let views14 = ["button": button14]
        let constraintHorizontal14 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-170-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views14)
        view.addConstraints(constraintHorizontal14)
        let constraintWertical14 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-260-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views14)
        view.addConstraints(constraintWertical14)
        
        button15.backgroundColor = UIColor.white
        button15.setTitle("M", for: .normal)
        button15.addTarget(self, action: #selector(buttonAction2), for: .touchUpInside)
        self.view.addSubview(button15)
        button15.translatesAutoresizingMaskIntoConstraints = false
        let views15 = ["button": button15]
        let constraintHorizontal15 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-210-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views15)
        view.addConstraints(constraintHorizontal15)
        let constraintWertical15 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-260-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views15)
        view.addConstraints(constraintWertical15)
        
        button16.backgroundColor = UIColor.white
        button16.setTitle("A", for: .normal)
        button16.addTarget(self, action: #selector(buttonAction9), for: .touchUpInside)
        self.view.addSubview(button16)
        button16.translatesAutoresizingMaskIntoConstraints = false
        let views16 = ["button": button16]
        let constraintHorizontal16 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-50-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views16)
        view.addConstraints(constraintHorizontal16)
        let constraintWertical16 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-340-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views16)
        view.addConstraints(constraintWertical16)
        
        button17.backgroundColor = UIColor.white
        button17.setTitle("I", for: .normal)
        button17.addTarget(self, action: #selector(buttonAction11), for: .touchUpInside)
        self.view.addSubview(button17)
        button17.translatesAutoresizingMaskIntoConstraints = false
        let views17 = ["button": button17]
        let constraintHorizontal17 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-130-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views17)
        view.addConstraints(constraintHorizontal17)
        let constraintWertical17 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-340-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views17)
        view.addConstraints(constraintWertical17)
        
        button18.backgroundColor = UIColor.white
        button18.setTitle("L", for: .normal)
        button18.addTarget(self, action: #selector(buttonAction4), for: .touchUpInside)
        self.view.addSubview(button18)
        button18.translatesAutoresizingMaskIntoConstraints = false
        let views18 = ["button": button18]
        let constraintHorizontal18 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-290-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views18)
        view.addConstraints(constraintHorizontal18)
        let constraintWertical18 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-340-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views18)
        view.addConstraints(constraintWertical18)
        
        button19.backgroundColor = UIColor.white
        button19.setTitle("O", for: .normal)
        button19.addTarget(self, action: #selector(buttonAction8), for: .touchUpInside)
        self.view.addSubview(button19)
        button19.translatesAutoresizingMaskIntoConstraints = false
        let views19 = ["button": button19]
        let constraintHorizontal19 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-130-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views19)
        view.addConstraints(constraintHorizontal19)
        let constraintWertical19 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-380-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views19)
        view.addConstraints(constraintWertical19)
        
        button20.backgroundColor = UIColor.white
        button20.setTitle("F", for: .normal)
        button20.addTarget(self, action: #selector(buttonAction8), for: .touchUpInside)
        self.view.addSubview(button20)
        button20.translatesAutoresizingMaskIntoConstraints = false
        let views20 = ["button": button20]
        let constraintHorizontal20 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-170-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views20)
        view.addConstraints(constraintHorizontal20)
        let constraintWertical20 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-380-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views20)
        view.addConstraints(constraintWertical20)
        
        button21.backgroundColor = UIColor.white
        button21.setTitle("C", for: .normal)
        button21.addTarget(self, action: #selector(buttonAction8), for: .touchUpInside)
        self.view.addSubview(button21)
        button21.translatesAutoresizingMaskIntoConstraints = false
        let views21 = ["button": button21]
        let constraintHorizontal21 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-290-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views21)
        view.addConstraints(constraintHorizontal21)
        let constraintWertical21 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-380-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views21)
        view.addConstraints(constraintWertical21)
        
        button22.backgroundColor = UIColor.white
        button22.setTitle("E", for: .normal)
        button22.addTarget(self, action: #selector(buttonAction8), for: .touchUpInside)
        self.view.addSubview(button22)
        button22.translatesAutoresizingMaskIntoConstraints = false
        let views22 = ["button": button22]
        let constraintHorizontal22 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-330-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views22)
        view.addConstraints(constraintHorizontal22)
        let constraintWertical22 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-380-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views22)
        view.addConstraints(constraintWertical22)
        
        button23.backgroundColor = UIColor.white
        button23.setTitle("E", for: .normal)
        button23.addTarget(self, action: #selector(buttonAction5), for: .touchUpInside)
        self.view.addSubview(button23)
        button23.translatesAutoresizingMaskIntoConstraints = false
        let views23 = ["button": button23]
        let constraintHorizontal23 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-90-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views23)
        view.addConstraints(constraintHorizontal23)
        let constraintWertical23 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-420-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views23)
        view.addConstraints(constraintWertical23)
        
        button24.backgroundColor = UIColor.white
        button24.setTitle("N", for: .normal)
        button24.addTarget(self, action: #selector(buttonAction5), for: .touchUpInside)
        self.view.addSubview(button24)
        button24.translatesAutoresizingMaskIntoConstraints = false
        let views24 = ["button": button24]
        let constraintHorizontal24 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-130-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views24)
        view.addConstraints(constraintHorizontal24)
        let constraintWertical24 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-420-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views24)
        view.addConstraints(constraintWertical24)
        
        button25.backgroundColor = UIColor.white
        button25.setTitle("D", for: .normal)
        button25.addTarget(self, action: #selector(buttonAction5), for: .touchUpInside)
        self.view.addSubview(button25)
        button25.translatesAutoresizingMaskIntoConstraints = false
        let views25 = ["button": button25]
        let constraintHorizontal25 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-170-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views25)
        view.addConstraints(constraintHorizontal25)
        let constraintWertical25 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-420-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views25)
        view.addConstraints(constraintWertical25)
        
        button28.backgroundColor = UIColor.white
        button28.setTitle("J", for: .normal)
        button28.addTarget(self, action: #selector(buttonAction6), for: .touchUpInside)
        self.view.addSubview(button28)
        button28.translatesAutoresizingMaskIntoConstraints = false
        let views28 = ["button": button28]
        let constraintHorizontal28 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-10-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views28)
        view.addConstraints(constraintHorizontal28)
        let constraintWertical28 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-140-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views28)
        view.addConstraints(constraintWertical28)
        
        button29.backgroundColor = UIColor.white
        button29.setTitle("O", for: .normal)
        button29.addTarget(self, action: #selector(buttonAction6), for: .touchUpInside)
        self.view.addSubview(button29)
        button29.translatesAutoresizingMaskIntoConstraints = false
        let views29 = ["button": button29]
        let constraintHorizontal29 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-50-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views29)
        view.addConstraints(constraintHorizontal29)
        let constraintWertical29 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-140-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views29)
        view.addConstraints(constraintWertical29)
        
        button30.backgroundColor = UIColor.white
        button30.setTitle("Y", for: .normal)
        button30.addTarget(self, action: #selector(buttonAction6), for: .touchUpInside)
        self.view.addSubview(button30)
        button30.translatesAutoresizingMaskIntoConstraints = false
        let views30 = ["button": button30]
        let constraintHorizontal30 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-90-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views30)
        view.addConstraints(constraintHorizontal30)
        let constraintWertical30 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-140-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views30)
        view.addConstraints(constraintWertical30)
        
        button31.backgroundColor = UIColor.white
        button31.setTitle("I", for: .normal)
        button31.addTarget(self, action: #selector(buttonAction7), for: .touchUpInside)
        self.view.addSubview(button31)
        button31.translatesAutoresizingMaskIntoConstraints = false
        let views31 = ["button": button31]
        let constraintHorizontal31 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-170-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views31)
        view.addConstraints(constraintHorizontal31)
        let constraintWertical31 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-140-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views31)
        view.addConstraints(constraintWertical31)
        
        button32.backgroundColor = UIColor.white
        button32.setTitle("N", for: .normal)
        button32.addTarget(self, action: #selector(buttonAction7), for: .touchUpInside)
        self.view.addSubview(button32)
        button32.translatesAutoresizingMaskIntoConstraints = false
        let views32 = ["button": button32]
        let constraintHorizontal32 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-210-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views32)
        view.addConstraints(constraintHorizontal32)
        let constraintWertical32 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-140-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views32)
        view.addConstraints(constraintWertical32)
        
        button33.backgroundColor = UIColor.white
        button33.setTitle("T", for: .normal)
        button33.addTarget(self, action: #selector(buttonAction7), for: .touchUpInside)
        self.view.addSubview(button33)
        button33.translatesAutoresizingMaskIntoConstraints = false
        let views33 = ["button": button33]
        let constraintHorizontal33 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-250-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views33)
        view.addConstraints(constraintHorizontal33)
        let constraintWertical33 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-140-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views33)
        view.addConstraints(constraintWertical33)
        
        button34.backgroundColor = UIColor.white
        button34.setTitle("E", for: .normal)
        button34.addTarget(self, action: #selector(buttonAction7), for: .touchUpInside)
        self.view.addSubview(button34)
        button34.translatesAutoresizingMaskIntoConstraints = false
        let views34 = ["button": button34]
        let constraintHorizontal34 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-290-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views34)
        view.addConstraints(constraintHorizontal34)
        let constraintWertical34 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-140-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views34)
        view.addConstraints(constraintWertical34)
        
        button35.backgroundColor = UIColor.white
        button35.setTitle("L", for: .normal)
        button35.addTarget(self, action: #selector(buttonAction7), for: .touchUpInside)
        self.view.addSubview(button35)
        button35.translatesAutoresizingMaskIntoConstraints = false
        let views35 = ["button": button35]
        let constraintHorizontal35 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-330-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views35)
        view.addConstraints(constraintHorizontal35)
        let constraintWertical35 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-140-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views35)
        view.addConstraints(constraintWertical35)
        
        button36.backgroundColor = UIColor.white
        button36.setTitle("E", for: .normal)
        button36.addTarget(self, action: #selector(buttonAction10), for: .touchUpInside)
        self.view.addSubview(button36)
        button36.translatesAutoresizingMaskIntoConstraints = false
        let views36 = ["button": button36]
        let constraintHorizontal36 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-170-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views36)
        view.addConstraints(constraintHorizontal36)
        let constraintWertical36 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-220-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views36)
        view.addConstraints(constraintWertical36)
        
        button37.backgroundColor = UIColor.white
        button37.setTitle("O", for: .normal)
        button37.addTarget(self, action: #selector(buttonAction2), for: .touchUpInside)
        self.view.addSubview(button37)
        button37.translatesAutoresizingMaskIntoConstraints = false
        let views37 = ["button": button37]
        let constraintHorizontal37 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-210-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views37)
        view.addConstraints(constraintHorizontal37)
        let constraintWertical37 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-220-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views37)
        view.addConstraints(constraintWertical37)
        
        button38.backgroundColor = UIColor.white
        button38.setTitle("T", for: .normal)
        button38.addTarget(self, action: #selector(buttonAction4), for: .touchUpInside)
        self.view.addSubview(button38)
        button38.translatesAutoresizingMaskIntoConstraints = false
        let views38 = ["button": button38]
        let constraintHorizontal38 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-290-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views38)
        view.addConstraints(constraintHorizontal38)
        let constraintWertical38 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-220-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views38)
        view.addConstraints(constraintWertical38)
        
        button39.backgroundColor = UIColor.white
        button39.setTitle("R", for: .normal)
        button39.addTarget(self, action: #selector(buttonAction4), for: .touchUpInside)
        self.view.addSubview(button39)
        button39.translatesAutoresizingMaskIntoConstraints = false
        let views39 = ["button": button39]
        let constraintHorizontal39 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-290-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views39)
        view.addConstraints(constraintHorizontal39)
        let constraintWertical39 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-260-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views39)
        view.addConstraints(constraintWertical39)
        
        button40.backgroundColor = UIColor.white
        button40.setTitle("R", for: .normal)
        button40.addTarget(self, action: #selector(buttonAction9), for: .touchUpInside)
        self.view.addSubview(button40)
        button40.translatesAutoresizingMaskIntoConstraints = false
        let views40 = ["button": button40]
        let constraintHorizontal40 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-50-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views40)
        view.addConstraints(constraintHorizontal40)
        let constraintWertical40 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-300-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views40)
        view.addConstraints(constraintWertical40)
        
        button41.backgroundColor = UIColor.white
        button41.setTitle("N", for: .normal)
        button41.addTarget(self, action: #selector(buttonAction11), for: .touchUpInside)
        self.view.addSubview(button41)
        button41.translatesAutoresizingMaskIntoConstraints = false
        let views41 = ["button": button41]
        let constraintHorizontal41 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-130-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views41)
        view.addConstraints(constraintHorizontal41)
        let constraintWertical41 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-300-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views41)
        view.addConstraints(constraintWertical41)
        
        button42.backgroundColor = UIColor.white
        button42.setTitle("T", for: .normal)
        button42.addTarget(self, action: #selector(buttonAction10), for: .touchUpInside)
        self.view.addSubview(button42)
        button42.translatesAutoresizingMaskIntoConstraints = false
        let views42 = ["button": button42]
        let constraintHorizontal42 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-170-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views42)
        view.addConstraints(constraintHorizontal42)
        let constraintWertical42 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-300-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views42)
        view.addConstraints(constraintWertical42)
        
        button43.backgroundColor = UIColor.white
        button43.setTitle("E", for: .normal)
        button43.addTarget(self, action: #selector(buttonAction2), for: .touchUpInside)
        self.view.addSubview(button43)
        button43.translatesAutoresizingMaskIntoConstraints = false
        let views43 = ["button": button43]
        let constraintHorizontal43 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-210-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views43)
        view.addConstraints(constraintHorizontal43)
        let constraintWertical43 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-300-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views43)
        view.addConstraints(constraintWertical43)
        
        button44.backgroundColor = UIColor.white
        button44.setTitle("A", for: .normal)
        button44.addTarget(self, action: #selector(buttonAction4), for: .touchUpInside)
        self.view.addSubview(button44)
        button44.translatesAutoresizingMaskIntoConstraints = false
        let views44 = ["button": button44]
        let constraintHorizontal44 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-290-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views44)
        view.addConstraints(constraintHorizontal44)
        let constraintWertical44 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-300-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views44)
        view.addConstraints(constraintWertical44)
        
        button45.backgroundColor = UIColor.white
        button45.setTitle("F", for: .normal)
        button45.addTarget(self, action: #selector(buttonAction8), for: .touchUpInside)
        self.view.addSubview(button45)
        button45.translatesAutoresizingMaskIntoConstraints = false
        let views45 = ["button": button45]
        let constraintHorizontal45 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-210-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views45)
        view.addConstraints(constraintHorizontal45)
        let constraintWertical45 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-380-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views45)
        view.addConstraints(constraintWertical45)
        
        button46.backgroundColor = UIColor.white
        button46.setTitle("I", for: .normal)
        button46.addTarget(self, action: #selector(buttonAction8), for: .touchUpInside)
        self.view.addSubview(button46)
        button46.translatesAutoresizingMaskIntoConstraints = false
        let views46 = ["button": button46]
        let constraintHorizontal46 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-250-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views46)
        view.addConstraints(constraintHorizontal46)
        let constraintWertical46 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-380-[button]", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views46)
        view.addConstraints(constraintWertical46)
        
    }
    
    /*
     self.finishButton = UIButton(type: .custom)
     finishButton.setTitle("Finish!", for: [])
     finishButton.addTarget(self, action: #selector(finishAction), for: .touchUpInside)
     finishButton.setBackgroundImage(hintButtonImage, for: [])
     finishButton.frame = CGRect(x: 200,y: 500,width: hintButtonImage.size.width - 100,height: hintButtonImage.size.height - 20)
     finishButton.alpha = 0.8
     self.view.addSubview(finishButton)
     
    @objc func finishAction(sender: UIButton!) {
        self.showLevelMenu()
    }
    */
    
    @objc func buttonAction(sender: UIButton!) {
        
        for button in self.buttons1 {
            button.backgroundColor = UIColor.yellow
        }

        self.button6.backgroundColor = UIColor.white
        self.button7.backgroundColor = UIColor.white
        self.button8.backgroundColor = UIColor.white
        self.button9.backgroundColor = UIColor.white
        self.button10.backgroundColor = UIColor.white
        self.button11.backgroundColor = UIColor.white
        self.button12.backgroundColor = UIColor.white
        self.button13.backgroundColor = UIColor.white
        self.button14.backgroundColor = UIColor.white
        self.button15.backgroundColor = UIColor.white
        self.button16.backgroundColor = UIColor.white
        self.button17.backgroundColor = UIColor.white
        self.button18.backgroundColor = UIColor.white
        self.button19.backgroundColor = UIColor.white
        self.button20.backgroundColor = UIColor.white
        self.button21.backgroundColor = UIColor.white
        self.button22.backgroundColor = UIColor.white
        self.button23.backgroundColor = UIColor.white
        self.button24.backgroundColor = UIColor.white
        self.button25.backgroundColor = UIColor.white
        self.button28.backgroundColor = UIColor.white
        self.button29.backgroundColor = UIColor.white
        self.button30.backgroundColor = UIColor.white
        self.button31.backgroundColor = UIColor.white
        self.button32.backgroundColor = UIColor.white
        self.button33.backgroundColor = UIColor.white
        self.button34.backgroundColor = UIColor.white
        self.button35.backgroundColor = UIColor.white
        self.button36.backgroundColor = UIColor.white
        self.button40.backgroundColor = UIColor.white
        self.button42.backgroundColor = UIColor.white
        self.button45.backgroundColor = UIColor.white
        self.button46.backgroundColor = UIColor.white
        self.button37.backgroundColor = UIColor.white
        self.button43.backgroundColor = UIColor.white
        self.button38.backgroundColor = UIColor.white
        self.button39.backgroundColor = UIColor.white
        self.button44.backgroundColor = UIColor.white
        self.button41.backgroundColor = UIColor.white
        
        
        for button in self.buttons12 {
            button.isEnabled = false
        }
        for button in self.buttons1 {
            button.setTitleColor(.yellow, for: .normal)
            
        }
        buttonsDisable.append(button1)
        buttonsDisable.append(button4)
        buttonsDisable.append(button3)
        buttonsDisable.append(button2)
        buttonsDisable.append(button5)
        buttonsDisable.append(button27)
        buttonsDisable.append(button26)
        
        controller.dealRandomAnagram(index: 0)
    }
    
    @objc func buttonAction2(sender: UIButton!) {
        self.button1.backgroundColor = UIColor.white
        self.button2.backgroundColor = UIColor.white
        self.button3.backgroundColor = UIColor.white
        self.button4.backgroundColor = UIColor.white
        self.button5.backgroundColor = UIColor.white
        self.button6.backgroundColor = UIColor.white
        self.button7.backgroundColor = UIColor.white
        self.button9.backgroundColor = UIColor.white
        self.button10.backgroundColor = UIColor.white
        self.button11.backgroundColor = UIColor.white
        self.button12.backgroundColor = UIColor.white
        self.button13.backgroundColor = UIColor.white
        self.button14.backgroundColor = UIColor.white
        self.button16.backgroundColor = UIColor.white
        self.button17.backgroundColor = UIColor.white
        self.button18.backgroundColor = UIColor.white
        self.button19.backgroundColor = UIColor.white
        self.button20.backgroundColor = UIColor.white
        self.button21.backgroundColor = UIColor.white
        self.button22.backgroundColor = UIColor.white
        self.button23.backgroundColor = UIColor.white
        self.button24.backgroundColor = UIColor.white
        self.button25.backgroundColor = UIColor.white
        self.button26.backgroundColor = UIColor.white
        self.button28.backgroundColor = UIColor.white
        self.button29.backgroundColor = UIColor.white
        self.button30.backgroundColor = UIColor.white
        self.button31.backgroundColor = UIColor.white
        self.button33.backgroundColor = UIColor.white
        self.button34.backgroundColor = UIColor.white
        self.button35.backgroundColor = UIColor.white
        self.button36.backgroundColor = UIColor.white
        self.button40.backgroundColor = UIColor.white
        self.button42.backgroundColor = UIColor.white
        self.button45.backgroundColor = UIColor.white
        self.button46.backgroundColor = UIColor.white
        self.button38.backgroundColor = UIColor.white
        self.button39.backgroundColor = UIColor.white
        self.button44.backgroundColor = UIColor.white
        self.button41.backgroundColor = UIColor.white
        
        for button in self.buttons3 {
            button.backgroundColor = UIColor.yellow
        }
        for button in self.buttons12 {
            button.isEnabled = false
        }
        for button in self.buttons3 {
            button.setTitleColor(.yellow, for: .normal)
        }
        
        buttonsDisable.append(button8)
        buttonsDisable.append(button15)
        buttonsDisable.append(button27)
        buttonsDisable.append(button32)
        buttonsDisable.append(button37)
        buttonsDisable.append(button43)
        
        controller.dealRandomAnagram(index: 8)
    }
    
    @objc func buttonAction3(sender: UIButton!) {
        self.button1.backgroundColor = UIColor.white
        self.button2.backgroundColor = UIColor.white
        self.button3.backgroundColor = UIColor.white
        self.button4.backgroundColor = UIColor.white
        self.button5.backgroundColor = UIColor.white
        self.button6.backgroundColor = UIColor.white
        self.button7.backgroundColor = UIColor.white
        self.button8.backgroundColor = UIColor.white
        self.button9.backgroundColor = UIColor.white
        self.button10.backgroundColor = UIColor.white
        self.button15.backgroundColor = UIColor.white
        self.button16.backgroundColor = UIColor.white
        self.button17.backgroundColor = UIColor.white
        self.button18.backgroundColor = UIColor.white
        self.button19.backgroundColor = UIColor.white
        self.button20.backgroundColor = UIColor.white
        self.button21.backgroundColor = UIColor.white
        self.button22.backgroundColor = UIColor.white
        self.button23.backgroundColor = UIColor.white
        self.button24.backgroundColor = UIColor.white
        self.button25.backgroundColor = UIColor.white
        self.button26.backgroundColor = UIColor.white
        self.button27.backgroundColor = UIColor.white
        self.button28.backgroundColor = UIColor.white
        self.button29.backgroundColor = UIColor.white
        self.button30.backgroundColor = UIColor.white
        self.button31.backgroundColor = UIColor.white
        self.button32.backgroundColor = UIColor.white
        self.button33.backgroundColor = UIColor.white
        self.button34.backgroundColor = UIColor.white
        self.button35.backgroundColor = UIColor.white
        self.button36.backgroundColor = UIColor.white
        self.button40.backgroundColor = UIColor.white
        self.button42.backgroundColor = UIColor.white
        self.button45.backgroundColor = UIColor.white
        self.button46.backgroundColor = UIColor.white
        self.button37.backgroundColor = UIColor.white
        self.button43.backgroundColor = UIColor.white
        self.button38.backgroundColor = UIColor.white
        self.button39.backgroundColor = UIColor.white
        self.button44.backgroundColor = UIColor.white
        self.button41.backgroundColor = UIColor.white
        
        for button in self.buttons4 {
            button.backgroundColor = UIColor.yellow
        }
        for button in self.buttons12 {
            button.isEnabled = false
        }
        for button in self.buttons4 {
            button.setTitleColor(.yellow, for: .normal)
        }
        
        buttonsDisable.append(button11)
        buttonsDisable.append(button12)
        buttonsDisable.append(button13)
        buttonsDisable.append(button14)
        
        controller.dealRandomAnagram(index: 5)
    }
    
    @objc func buttonAction4(sender: UIButton!) {
        self.button1.backgroundColor = UIColor.white
        self.button2.backgroundColor = UIColor.white
        self.button3.backgroundColor = UIColor.white
        self.button4.backgroundColor = UIColor.white
        self.button6.backgroundColor = UIColor.white
        self.button7.backgroundColor = UIColor.white
        self.button8.backgroundColor = UIColor.white
        self.button10.backgroundColor = UIColor.white
        self.button11.backgroundColor = UIColor.white
        self.button12.backgroundColor = UIColor.white
        self.button13.backgroundColor = UIColor.white
        self.button14.backgroundColor = UIColor.white
        self.button15.backgroundColor = UIColor.white
        self.button16.backgroundColor = UIColor.white
        self.button17.backgroundColor = UIColor.white
        self.button19.backgroundColor = UIColor.white
        self.button20.backgroundColor = UIColor.white
        self.button21.backgroundColor = UIColor.white
        self.button22.backgroundColor = UIColor.white
        self.button23.backgroundColor = UIColor.white
        self.button24.backgroundColor = UIColor.white
        self.button25.backgroundColor = UIColor.white
        self.button26.backgroundColor = UIColor.white
        self.button27.backgroundColor = UIColor.white
        self.button28.backgroundColor = UIColor.white
        self.button29.backgroundColor = UIColor.white
        self.button30.backgroundColor = UIColor.white
        self.button31.backgroundColor = UIColor.white
        self.button32.backgroundColor = UIColor.white
        self.button33.backgroundColor = UIColor.white
        self.button35.backgroundColor = UIColor.white
        self.button36.backgroundColor = UIColor.white
        self.button40.backgroundColor = UIColor.white
        self.button42.backgroundColor = UIColor.white
        self.button45.backgroundColor = UIColor.white
        self.button46.backgroundColor = UIColor.white
        self.button37.backgroundColor = UIColor.white
        self.button43.backgroundColor = UIColor.white
        self.button41.backgroundColor = UIColor.white
        
        for button in self.buttons5 {
            button.backgroundColor = UIColor.yellow
        }
        for button in self.buttons12 {
            button.isEnabled = false
        }
        for button in self.buttons5 {
            button.setTitleColor(.yellow, for: .normal)
        }
        
        buttonsDisable.append(button5)
        buttonsDisable.append(button9)
        buttonsDisable.append(button18)
        buttonsDisable.append(button34)
        buttonsDisable.append(button38)
        buttonsDisable.append(button39)
        buttonsDisable.append(button44)
        
        controller.dealRandomAnagram(index: 10)
    }
    
    @objc func buttonAction5(sender: UIButton!) {
        self.button1.backgroundColor = UIColor.white
        self.button2.backgroundColor = UIColor.white
        self.button3.backgroundColor = UIColor.white
        self.button4.backgroundColor = UIColor.white
        self.button5.backgroundColor = UIColor.white
        self.button6.backgroundColor = UIColor.white
        self.button7.backgroundColor = UIColor.white
        self.button8.backgroundColor = UIColor.white
        self.button9.backgroundColor = UIColor.white
        self.button10.backgroundColor = UIColor.white
        self.button11.backgroundColor = UIColor.white
        self.button12.backgroundColor = UIColor.white
        self.button13.backgroundColor = UIColor.white
        self.button14.backgroundColor = UIColor.white
        self.button15.backgroundColor = UIColor.white
        self.button16.backgroundColor = UIColor.white
        self.button17.backgroundColor = UIColor.white
        self.button18.backgroundColor = UIColor.white
        self.button19.backgroundColor = UIColor.white
        self.button20.backgroundColor = UIColor.white
        self.button21.backgroundColor = UIColor.white
        self.button22.backgroundColor = UIColor.white
        self.button26.backgroundColor = UIColor.white
        self.button27.backgroundColor = UIColor.white
        self.button28.backgroundColor = UIColor.white
        self.button29.backgroundColor = UIColor.white
        self.button30.backgroundColor = UIColor.white
        self.button31.backgroundColor = UIColor.white
        self.button32.backgroundColor = UIColor.white
        self.button33.backgroundColor = UIColor.white
        self.button34.backgroundColor = UIColor.white
        self.button35.backgroundColor = UIColor.white
        self.button36.backgroundColor = UIColor.white
        self.button40.backgroundColor = UIColor.white
        self.button42.backgroundColor = UIColor.white
        self.button45.backgroundColor = UIColor.white
        self.button46.backgroundColor = UIColor.white
        self.button37.backgroundColor = UIColor.white
        self.button43.backgroundColor = UIColor.white
        self.button38.backgroundColor = UIColor.white
        self.button39.backgroundColor = UIColor.white
        self.button44.backgroundColor = UIColor.white
        self.button41.backgroundColor = UIColor.white
        
        for button in self.buttons6 {
            button.backgroundColor = UIColor.yellow
        }
        for button in self.buttons12 {
            button.isEnabled = false
        }
        for button in self.buttons6 {
            button.setTitleColor(.yellow, for: .normal)
        }
        
        buttonsDisable.append(button23)
        buttonsDisable.append(button24)
        buttonsDisable.append(button25)
        
        controller.dealRandomAnagram(index: 7)
    }
    
    @objc func buttonAction6(sender: UIButton!) {
        self.button1.backgroundColor = UIColor.white
        self.button2.backgroundColor = UIColor.white
        self.button3.backgroundColor = UIColor.white
        self.button4.backgroundColor = UIColor.white
        self.button5.backgroundColor = UIColor.white
        self.button6.backgroundColor = UIColor.white
        self.button7.backgroundColor = UIColor.white
        self.button8.backgroundColor = UIColor.white
        self.button9.backgroundColor = UIColor.white
        self.button10.backgroundColor = UIColor.white
        self.button11.backgroundColor = UIColor.white
        self.button12.backgroundColor = UIColor.white
        self.button13.backgroundColor = UIColor.white
        self.button14.backgroundColor = UIColor.white
        self.button15.backgroundColor = UIColor.white
        self.button16.backgroundColor = UIColor.white
        self.button17.backgroundColor = UIColor.white
        self.button18.backgroundColor = UIColor.white
        self.button19.backgroundColor = UIColor.white
        self.button20.backgroundColor = UIColor.white
        self.button21.backgroundColor = UIColor.white
        self.button22.backgroundColor = UIColor.white
        self.button23.backgroundColor = UIColor.white
        self.button24.backgroundColor = UIColor.white
        self.button25.backgroundColor = UIColor.white
        self.button26.backgroundColor = UIColor.white
        self.button27.backgroundColor = UIColor.white
        self.button31.backgroundColor = UIColor.white
        self.button32.backgroundColor = UIColor.white
        self.button33.backgroundColor = UIColor.white
        self.button34.backgroundColor = UIColor.white
        self.button35.backgroundColor = UIColor.white
        self.button36.backgroundColor = UIColor.white
        self.button40.backgroundColor = UIColor.white
        self.button42.backgroundColor = UIColor.white
        self.button45.backgroundColor = UIColor.white
        self.button46.backgroundColor = UIColor.white
        self.button37.backgroundColor = UIColor.white
        self.button43.backgroundColor = UIColor.white
        self.button38.backgroundColor = UIColor.white
        self.button39.backgroundColor = UIColor.white
        self.button44.backgroundColor = UIColor.white
        self.button41.backgroundColor = UIColor.white
        
        for button in self.buttons2 {
            button.backgroundColor = UIColor.yellow
        }
        for button in self.buttons12 {
            button.isEnabled = false
        }
        for button in self.buttons2 {
            button.setTitleColor(.yellow, for: .normal)
        }
        buttonsDisable.append(button28)
        buttonsDisable.append(button29)
        buttonsDisable.append(button30)
        controller.dealRandomAnagram(index: 1)
        
    }
    
    @objc func buttonAction7(sender: UIButton!) {
        self.button1.backgroundColor = UIColor.white
        self.button2.backgroundColor = UIColor.white
        self.button3.backgroundColor = UIColor.white
        self.button4.backgroundColor = UIColor.white
        self.button5.backgroundColor = UIColor.white
        self.button6.backgroundColor = UIColor.white
        self.button7.backgroundColor = UIColor.white
        self.button8.backgroundColor = UIColor.white
        self.button9.backgroundColor = UIColor.white
        self.button10.backgroundColor = UIColor.white
        self.button11.backgroundColor = UIColor.white
        self.button12.backgroundColor = UIColor.white
        self.button13.backgroundColor = UIColor.white
        self.button14.backgroundColor = UIColor.white
        self.button15.backgroundColor = UIColor.white
        self.button16.backgroundColor = UIColor.white
        self.button17.backgroundColor = UIColor.white
        self.button18.backgroundColor = UIColor.white
        self.button19.backgroundColor = UIColor.white
        self.button20.backgroundColor = UIColor.white
        self.button21.backgroundColor = UIColor.white
        self.button22.backgroundColor = UIColor.white
        self.button23.backgroundColor = UIColor.white
        self.button24.backgroundColor = UIColor.white
        self.button25.backgroundColor = UIColor.white
        self.button26.backgroundColor = UIColor.white
        self.button27.backgroundColor = UIColor.white
        self.button28.backgroundColor = UIColor.white
        self.button29.backgroundColor = UIColor.white
        self.button30.backgroundColor = UIColor.white
        self.button36.backgroundColor = UIColor.white
        self.button40.backgroundColor = UIColor.white
        self.button42.backgroundColor = UIColor.white
        self.button45.backgroundColor = UIColor.white
        self.button46.backgroundColor = UIColor.white
        self.button37.backgroundColor = UIColor.white
        self.button43.backgroundColor = UIColor.white
        self.button38.backgroundColor = UIColor.white
        self.button39.backgroundColor = UIColor.white
        self.button44.backgroundColor = UIColor.white
        self.button41.backgroundColor = UIColor.white
        
        for button in self.buttons7 {
            button.backgroundColor = UIColor.yellow
        }
        for button in self.buttons12 {
            button.isEnabled = false
        }
        for button in self.buttons7 {
            button.setTitleColor(.yellow, for: .normal)
        }
        
        buttonsDisable.append(button31)
        buttonsDisable.append(button32)
        buttonsDisable.append(button33)
        buttonsDisable.append(button34)
        buttonsDisable.append(button35)
        
        controller.dealRandomAnagram(index: 2)
    }
    
    @objc func buttonAction8(sender: UIButton!) {
        self.button1.backgroundColor = UIColor.white
        self.button2.backgroundColor = UIColor.white
        self.button3.backgroundColor = UIColor.white
        self.button4.backgroundColor = UIColor.white
        self.button5.backgroundColor = UIColor.white
        self.button26.backgroundColor = UIColor.white
        self.button27.backgroundColor = UIColor.white
        self.button6.backgroundColor = UIColor.white
        self.button7.backgroundColor = UIColor.white
        self.button8.backgroundColor = UIColor.white
        self.button9.backgroundColor = UIColor.white
        self.button10.backgroundColor = UIColor.white
        self.button11.backgroundColor = UIColor.white
        self.button12.backgroundColor = UIColor.white
        self.button13.backgroundColor = UIColor.white
        self.button14.backgroundColor = UIColor.white
        self.button15.backgroundColor = UIColor.white
        self.button16.backgroundColor = UIColor.white
        self.button17.backgroundColor = UIColor.white
        self.button18.backgroundColor = UIColor.white
        self.button23.backgroundColor = UIColor.white
        self.button24.backgroundColor = UIColor.white
        self.button25.backgroundColor = UIColor.white
        self.button28.backgroundColor = UIColor.white
        self.button29.backgroundColor = UIColor.white
        self.button30.backgroundColor = UIColor.white
        self.button31.backgroundColor = UIColor.white
        self.button32.backgroundColor = UIColor.white
        self.button33.backgroundColor = UIColor.white
        self.button34.backgroundColor = UIColor.white
        self.button35.backgroundColor = UIColor.white
        self.button36.backgroundColor = UIColor.white
        self.button40.backgroundColor = UIColor.white
        self.button42.backgroundColor = UIColor.white
        self.button37.backgroundColor = UIColor.white
        self.button43.backgroundColor = UIColor.white
        self.button38.backgroundColor = UIColor.white
        self.button39.backgroundColor = UIColor.white
        self.button44.backgroundColor = UIColor.white
        self.button41.backgroundColor = UIColor.white
        
        for button in self.buttons8 {
            button.backgroundColor = UIColor.yellow
        }
        for button in self.buttons12 {
            button.isEnabled = false
        }
        for button in self.buttons8 {
            button.setTitleColor(.yellow, for: .normal)
        }
        
        buttonsDisable.append(button19)
        buttonsDisable.append(button20)
        buttonsDisable.append(button21)
        buttonsDisable.append(button22)
        buttonsDisable.append(button45)
        buttonsDisable.append(button46)
        
        controller.dealRandomAnagram(index: 4)
    }
    
    @objc func buttonAction9(sender: UIButton!) {
        self.button2.backgroundColor = UIColor.white
        self.button3.backgroundColor = UIColor.white
        self.button4.backgroundColor = UIColor.white
        self.button5.backgroundColor = UIColor.white
        self.button26.backgroundColor = UIColor.white
        self.button27.backgroundColor = UIColor.white
        self.button7.backgroundColor = UIColor.white
        self.button8.backgroundColor = UIColor.white
        self.button9.backgroundColor = UIColor.white
        self.button12.backgroundColor = UIColor.white
        self.button13.backgroundColor = UIColor.white
        self.button14.backgroundColor = UIColor.white
        self.button15.backgroundColor = UIColor.white
        self.button17.backgroundColor = UIColor.white
        self.button18.backgroundColor = UIColor.white
        self.button19.backgroundColor = UIColor.white
        self.button20.backgroundColor = UIColor.white
        self.button21.backgroundColor = UIColor.white
        self.button22.backgroundColor = UIColor.white
        self.button23.backgroundColor = UIColor.white
        self.button24.backgroundColor = UIColor.white
        self.button25.backgroundColor = UIColor.white
        self.button28.backgroundColor = UIColor.white
        self.button30.backgroundColor = UIColor.white
        self.button31.backgroundColor = UIColor.white
        self.button32.backgroundColor = UIColor.white
        self.button33.backgroundColor = UIColor.white
        self.button34.backgroundColor = UIColor.white
        self.button35.backgroundColor = UIColor.white
        self.button36.backgroundColor = UIColor.white
        self.button42.backgroundColor = UIColor.white
        self.button45.backgroundColor = UIColor.white
        self.button46.backgroundColor = UIColor.white
        self.button37.backgroundColor = UIColor.white
        self.button43.backgroundColor = UIColor.white
        self.button38.backgroundColor = UIColor.white
        self.button39.backgroundColor = UIColor.white
        self.button44.backgroundColor = UIColor.white
        self.button41.backgroundColor = UIColor.white
        
        for button in self.buttons9 {
            button.backgroundColor = UIColor.yellow
        }
        for button in self.buttons12 {
            button.isEnabled = false
        }
        for button in self.buttons9 {
            button.setTitleColor(.yellow, for: .normal)
        }
        
        buttonsDisable.append(button1)
        buttonsDisable.append(button6)
        buttonsDisable.append(button10)
        buttonsDisable.append(button11)
        buttonsDisable.append(button16)
        buttonsDisable.append(button29)
        buttonsDisable.append(button40)
        
        controller.dealRandomAnagram(index: 3)
        
    }
    
    @objc func buttonAction10(sender: UIButton!) {
        self.button1.backgroundColor = UIColor.white
        self.button2.backgroundColor = UIColor.white
        self.button4.backgroundColor = UIColor.white
        self.button5.backgroundColor = UIColor.white
        self.button26.backgroundColor = UIColor.white
        self.button27.backgroundColor = UIColor.white
        self.button6.backgroundColor = UIColor.white
        self.button8.backgroundColor = UIColor.white
        self.button9.backgroundColor = UIColor.white
        self.button10.backgroundColor = UIColor.white
        self.button11.backgroundColor = UIColor.white
        self.button12.backgroundColor = UIColor.white
        self.button13.backgroundColor = UIColor.white
        self.button15.backgroundColor = UIColor.white
        self.button16.backgroundColor = UIColor.white
        self.button17.backgroundColor = UIColor.white
        self.button18.backgroundColor = UIColor.white
        self.button19.backgroundColor = UIColor.white
        self.button20.backgroundColor = UIColor.white
        self.button21.backgroundColor = UIColor.white
        self.button22.backgroundColor = UIColor.white
        self.button23.backgroundColor = UIColor.white
        self.button24.backgroundColor = UIColor.white
        self.button25.backgroundColor = UIColor.white
        self.button28.backgroundColor = UIColor.white
        self.button29.backgroundColor = UIColor.white
        self.button30.backgroundColor = UIColor.white
        self.button32.backgroundColor = UIColor.white
        self.button33.backgroundColor = UIColor.white
        self.button34.backgroundColor = UIColor.white
        self.button35.backgroundColor = UIColor.white
        self.button40.backgroundColor = UIColor.white
        self.button45.backgroundColor = UIColor.white
        self.button46.backgroundColor = UIColor.white
        self.button37.backgroundColor = UIColor.white
        self.button43.backgroundColor = UIColor.white
        self.button38.backgroundColor = UIColor.white
        self.button39.backgroundColor = UIColor.white
        self.button44.backgroundColor = UIColor.white
        self.button41.backgroundColor = UIColor.white
        
        for button in self.buttons10 {
            button.backgroundColor = UIColor.yellow
        }
        for button in self.buttons12 {
            button.isEnabled = false
        }
        for button in self.buttons10 {
            button.setTitleColor(.yellow, for: .normal)
        }
        
        buttonsDisable.append(button3)
        buttonsDisable.append(button7)
        buttonsDisable.append(button14)
        buttonsDisable.append(button31)
        buttonsDisable.append(button36)
        buttonsDisable.append(button42)
        
        controller.dealRandomAnagram(index: 6)
    }
    
    @objc func buttonAction11(sender: UIButton!) {
        self.button1.backgroundColor = UIColor.white
        self.button2.backgroundColor = UIColor.white
        self.button3.backgroundColor = UIColor.white
        self.button4.backgroundColor = UIColor.white
        self.button5.backgroundColor = UIColor.white
        self.button26.backgroundColor = UIColor.white
        self.button27.backgroundColor = UIColor.white
        self.button6.backgroundColor = UIColor.white
        self.button7.backgroundColor = UIColor.white
        self.button8.backgroundColor = UIColor.white
        self.button9.backgroundColor = UIColor.white
        self.button10.backgroundColor = UIColor.white
        self.button11.backgroundColor = UIColor.white
        self.button12.backgroundColor = UIColor.white
        self.button14.backgroundColor = UIColor.white
        self.button15.backgroundColor = UIColor.white
        self.button16.backgroundColor = UIColor.white
        self.button18.backgroundColor = UIColor.white
        self.button20.backgroundColor = UIColor.white
        self.button21.backgroundColor = UIColor.white
        self.button22.backgroundColor = UIColor.white
        self.button23.backgroundColor = UIColor.white
        self.button25.backgroundColor = UIColor.white
        self.button28.backgroundColor = UIColor.white
        self.button29.backgroundColor = UIColor.white
        self.button30.backgroundColor = UIColor.white
        self.button31.backgroundColor = UIColor.white
        self.button32.backgroundColor = UIColor.white
        self.button33.backgroundColor = UIColor.white
        self.button34.backgroundColor = UIColor.white
        self.button35.backgroundColor = UIColor.white
        self.button36.backgroundColor = UIColor.white
        self.button40.backgroundColor = UIColor.white
        self.button42.backgroundColor = UIColor.white
        self.button45.backgroundColor = UIColor.white
        self.button46.backgroundColor = UIColor.white
        self.button37.backgroundColor = UIColor.white
        self.button43.backgroundColor = UIColor.white
        self.button38.backgroundColor = UIColor.white
        self.button39.backgroundColor = UIColor.white
        self.button44.backgroundColor = UIColor.white
        
        for button in self.buttons11 {
            button.backgroundColor = UIColor.yellow
        }
        for button in self.buttons12 {
            button.isEnabled = false
        }
        for button in self.buttons11 {
            button.setTitleColor(.yellow, for: .normal)
        }
        
        buttonsDisable.append(button13)
        buttonsDisable.append(button17)
        buttonsDisable.append(button19)
        buttonsDisable.append(button24)
        buttonsDisable.append(button41)
        
        controller.dealRandomAnagram(index: 9)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    func showLevelMenu() {
        //1 show the level selector menu
        let alertController = UIAlertController(title: "Welcome To The Game ",
                                                message: nil,
                                                preferredStyle:UIAlertController.Style.alert)
        
        //2 set up the menu actions
        let easy = UIAlertAction(title: "Start", style:.default,
                                 handler: {(alert:UIAlertAction!) in
                                    self.showLevel(levelNumber: 1)
        })
        
        //3 add the menu actions to the menu
        alertController.addAction(easy)
        
        //4 show the UIAlertController
        self.present(alertController, animated: true, completion: nil)
        
    }
    func showWord() {
        for button in self.buttons12 {
            button.backgroundColor = UIColor.white
            button.isEnabled = true
        }
        
        for button in self.buttonsDisable {
            button.isEnabled = false
            button.setTitleColor(.black, for: .normal)
        }
    }
    
    //5 show the appropriate level selected by the player
    func showLevel(levelNumber:Int) {
        controller.level = Level(levelNumber: levelNumber)
    }
    
    //show the game menu on app start
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.showLevelMenu()
    }
    
}


