//
//  HUBView.swift
//  Cross Puzzle Game
//
//  Created by CampusUser on 4/17/19.
//  Copyright © 2019 Big Nerd Ranch. All rights reserved.
//

import UIKit

class HUDView: UIView {
    
    var stopwatch: StopwatchView
    var gamePoints: CounterLabelView
    var hintButton: UIButton!
    
    //this should never be called
    required init(coder aDecoder:NSCoder) {
        fatalError("use init(frame:")
    }
    
    override init(frame:CGRect) {
        self.stopwatch = StopwatchView(frame:CGRect(x: ScreenWidth/2-150, y: 0, width: 300, height: 100))
        self.stopwatch.setSeconds(seconds: 0)
        
        self.gamePoints = CounterLabelView( frame: CGRect(x: ScreenWidth-125,y: 550,width: 200,height: 70))
        gamePoints.textColor = UIColor.red
        gamePoints.value = 0
        
        super.init(frame:frame)
        
        self.addSubview(gamePoints)
        
        //"points" label
        let pointsLabel = UILabel(frame: CGRect(x: ScreenWidth-200,y: 550,width: 140,height: 70))
        pointsLabel.backgroundColor = UIColor.clear
        pointsLabel.text = " Points:"
        pointsLabel.textColor = UIColor.red
        self.addSubview(pointsLabel)
        self.addSubview(self.stopwatch)
        self.isUserInteractionEnabled = true
        
        //load the button image
        let hintButtonImage = UIImage(named: "btn")!
        
        //the help button
        self.hintButton = UIButton(type: .custom)
        hintButton.setTitle("Hint!", for: [])
        hintButton.setBackgroundImage(hintButtonImage, for: [])
        hintButton.frame = CGRect(x: 40,y: 550,width: hintButtonImage.size.width - 100,height: hintButtonImage.size.height - 20)
        hintButton.alpha = 0.8
        self.addSubview(hintButton)
    }
    
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        //1 let touches through and only catch the ones on buttons
        let hitView = super.hitTest(point, with: event)
        
        //2
        if hitView is UIButton {
            return hitView
        }
        
        //3
        return nil
    }
}
