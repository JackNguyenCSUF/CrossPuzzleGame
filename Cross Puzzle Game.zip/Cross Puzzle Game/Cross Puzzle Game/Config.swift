//
//  Config.swift
//  Cross Puzzle Game
//
//  Created by CampusUser on 4/17/19.
//  Copyright © 2019 Big Nerd Ranch. All rights reserved.
//

import Foundation
import UIKit

//UI Constants
let ScreenWidth = UIScreen.main.bounds.size.width
let ScreenHeight = UIScreen.main.bounds.size.height
let TileMargin : CGFloat = 20.0
//let FontHUD = UIFont(name:"comic andy", size: 10.0)!
//let FontHUDBig = UIFont(name:"comic andy", size:20.0)!

// Sound effects
let SoundDing = "ding.mp3"
let SoundWrong = "wrong.m4a"
let SoundWin = "win.mp3"
let AudioEffectFiles = [SoundDing, SoundWrong, SoundWin]

//Random number generator
func randomNumber(min:UInt32, max:UInt32) -> Int {
    let result = (arc4random() % (max - min + 1)) + min
    return Int(result)
}

