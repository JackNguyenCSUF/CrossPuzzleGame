//
//  CounterLabelView.swift
//  Cross Puzzle Game
//
//  Created by CampusUser on 4/17/19.
//  Copyright © 2019 Big Nerd Ranch. All rights reserved.
//

import UIKit

class CounterLabelView: UILabel {
    
    //1
    var value:Int = 0 {
        //2
        didSet {
            self.text = " \(value)"
        }
    }
    
    required init(coder aDecoder:NSCoder) {
        fatalError("use init(font:frame:")
    }
    
    //3
    override init( frame:CGRect) {
        super.init(frame:frame)
        self.font = font
        self.backgroundColor = UIColor.clear
    }
}
